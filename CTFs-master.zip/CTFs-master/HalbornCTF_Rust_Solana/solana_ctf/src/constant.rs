const DEVNET_MODE:bool = true;
pub const FARM_FEE:u64 = 5000;
pub const FEE_OWNER:&str = if DEVNET_MODE {"BRmxAJ3ThceU2SXt6weyXarRNvAwZUtKuKbzSRneRxJn"} else {"4GJ3z4skEHJADz3MVeNYBg4YV8H27rBQey2YYdiPC8PA"};
pub const USDC_MINT_ADDRESS:&str = if DEVNET_MODE {"6MBRfPbzejwVpADXq3LCotZetje3N16m5Yn7LCs2ffU4"} else {"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"};
# Solana CTF

Here, you will find two Solana CTFs. 

It is mandatory to provide a PoC (Proof of Concept) to verify that the findings are vulnerable.

The candidate has to complete both CTFs.

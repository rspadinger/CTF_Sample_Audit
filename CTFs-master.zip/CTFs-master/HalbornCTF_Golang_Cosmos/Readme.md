# Golang Cosmos CTF

This CTF is written in Rust and related to Cosmos.

The CTF contains **5 vulnerabilities**. Candidates should be able to find at least 3 of them.

**Candidates should provide the steps for exploit the vulnerabilities as well as a script for performing it**
